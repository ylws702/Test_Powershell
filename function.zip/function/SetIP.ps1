function Set-IPConfig ([string]$ip,[string]$defaultGateWay) {
    
}