function Connect-SCUNET () {
    netsh wlan connect ssid="SCUNET" name="SCUNET"
}